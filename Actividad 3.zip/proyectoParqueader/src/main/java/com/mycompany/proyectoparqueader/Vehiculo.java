package com.mycompany.proyectoparqueader;

import java.time.LocalDateTime; //para que funcione el tipo de dato LocalDateTime
// clase en Java que representa una fecha y una hora sin zona horaria

public class Vehiculo {
    // atributos
    public String placa;
    public String marca;
    public String modelo;
    public LocalDateTime horaEntrada;

    //constructor con parametros
    public Vehiculo (String placa, String marca, String modelo, LocalDateTime horaEntrada) {
        this. placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.horaEntrada = horaEntrada;
    }

    //getters y setters
    //placa
    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;

    }
    //marca
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    //modelo
    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    //hora de entrada
    public LocalDateTime getHoraEntrada() {
        return horaEntrada;
    }

    public void setHoraEntrada(LocalDateTime horaEntrada) {
        this.horaEntrada = horaEntrada;
    }
}