package com.mycompany.proyectoparqueader;

import java.time.*;
import java.util.*;

public class Parqueadero {
    //atributos
    private List<Vehiculo> vehiculos; 
    // List -> tipo lista
    // < Vehiculo > --> restringe a que la lista solo tiene objetos de la clase Vehiculo
    // vehiculos --> nombre del atributo
    

    // constructor
    public Parqueadero() {
        this.vehiculos = new ArrayList<>();
    }

    // metodo que ingresa un objeto al atributo
    public void registrarEntrada(Vehiculo objeto) {
        vehiculos.add(objeto);
        // referencia al atributo vehiculos
        // .add(): método de la clase List que se utiliza para agregar un elemento a la lista
    }

    public void eliminarRegistro (Vehiculo objeto) {
        // crea un nuevo objeto de tipo iterador
        // iterador recorre una colección de elementos de manera secuencia
        Iterator <Vehiculo> recorredor = vehiculos.iterator();

        //crea un bucle para que el iterador busque
        while (recorredor.hasNext()) { //hasNext(): verifica si hay un siguiente elemento, elemento especificado en los {}
            Vehiculo veh =  recorredor.next(); // crea una nueva variable temporal veh
            if (veh.equals(objeto)) { // equals compara la varible "veh" con "objeto"
                recorredor.remove(); // se elimina el objeto al encontrarlo igual
                break; // sale del bucle al encontrar una coincidencia
            }
        }
    }

    public long calculoCosto (Vehiculo objeto) {
        // almacena la hora de salida generandola de la hora de la maquina
        LocalDateTime horaSalida = LocalDateTime.now();

        // crea un nuevo objeto que tipo Duration
        // compara entre la hora de entrada del objeto con la hora de salida 
        Duration duracion = Duration.between(objeto.horaEntrada, horaSalida);
        long horas = duracion.toHours();
        long minutos = duracion.toMinutesPart();

        // forma simplificada de un conficional
        // si es true la condicional suma lo que hay entre el ? y :
        // si es false suma lo que esta despues del :
        horas += (minutos>0) ? 1 : 0;
        
        //verificacion de tipo de vehiculo y asigacion del costro segunla duracion
        if (objeto instanceof Automovil) {
            horas *= 1000;
        }
        if (objeto instanceof Motocicleta) {
            horas *= 20000;
        }
        if (objeto instanceof Camion) {
            horas *= 200000;
        }
        return horas;
    }
    // metodo que recorre la lista de vehículos, compara la placa de cada vehículo con la placa que se esta buscando
    public Vehiculo buscarVehiculoPorPlaca(String placa) {
    for (Vehiculo variable : vehiculos) {
        if (variable.getPlaca().equals(placa)) {
            return variable;
        }
    }
    return null; // Si no encuentra el vehículo, devuelve null
}

    public void consultarEstado() {
    System.out.println("Vehiculos en el parqueadero:");
    System.out.println("------------------------");

    if (vehiculos.isEmpty()) {
        System.out.println("No hay vehículos en el parqueadero.");
    } else {
        for (Vehiculo vehiculo : vehiculos) {
            System.out.println("Placa: " + vehiculo.getPlaca());
            System.out.println("Marca: " + vehiculo.getMarca());
            System.out.println("Modelo: " + vehiculo.getModelo());

            LocalDateTime horaSalida = LocalDateTime.now();           
            Duration duracion = Duration.between(vehiculo.horaEntrada, horaSalida);
            long horas = duracion.toHours();
            long minutos = duracion.toMinutesPart();
            horas += (minutos>0) ? 1 : 0;
            
            System.out.println("Tiempo en parqueadero: " + horas + " horas.");
            System.out.println("------------------------");
        }
    }
    }
}