package com.mycompany.proyectoparqueader;

import java.time.*;

public class Motocicleta extends Vehiculo {
    // ATRIBUTOS
    // placa
    // marca
    // modelo
    // horaEntrada
    public int cilindraje;

    // contructor con parametros
    public Motocicleta (String placa, String marca, String modelo, LocalDateTime horaEntrada, int cilindraje) {
        super(placa, marca, modelo, horaEntrada); // super llama al constructor de la clase Vehiculo
        this.cilindraje = cilindraje;
    }

    // GETTERS Y SETTERS
    // cilindraje
    public int getCilindraje() {
        return cilindraje;
    }

    public void setCilindraje(int cilindraje) {
        this.cilindraje = cilindraje;
    }
}