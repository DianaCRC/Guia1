package com.mycompany.proyectoparqueader;

import java.time.*;
import java.util.*;

// clase derivada de Vehiculo
public class Automovil extends Vehiculo { 
    // ATRIBUTOS
    // placa
    // marca
    // modelo
    // horaEntrada
    private String tipoCombustible;

    // contructor con parametros
    public Automovil (String placa, String marca, String modelo, LocalDateTime horaEntrada, String tipoCombutible) {
        super(placa, marca, modelo, horaEntrada); // super llama al constructor de la clase Vehiculo
        this.tipoCombustible = tipoCombutible;
    }

    // GETTERS Y SETTERS
    // tipo de comustible
    public String getTipoCombustible() {
        return tipoCombustible;
    }

    public void setTipoComustible(String tipoCombustible) {
        this.tipoCombustible = tipoCombustible;
    }
}
