package com.mycompany.proyectoparqueader;

import java.time.*;
import java.util.*;

public class ProyectoParqueader {
    public static void main (String [] args) {
        Scanner lectura = new Scanner(System.in);
        Parqueadero parqueadero1 = new Parqueadero(); // crea el objeto parqueadero para guardar todos los vehiculos que se vayan a ingregar despues
        
        boolean salir = false;
        
        while (!salir) {
            //menu
            System.out.print("-------------- MENU --------------");
            System.out.println();
            System.out.print("1. Ingresar vehiculo."
                    + "");
            System.out.println();
            System.out.print("2. Registrar salida de vehiculo.");
            System.out.println();
            System.out.print("3. Consultar estado de parqueadero.");
            System.out.println();
             System.out.print("4. Salir.");
            System.out.println();
            System.out.print("¿Que desea hacer? (indique el numero de la opcion): ");
            int opcion = lectura.nextInt();

            // evaluar lo ingresado y almacenado en opcion y ejecuta1 el codigo segun el caso
            switch (opcion) {
                case 1: // registro de nuevo vehiculo
                    System.out.println("--------------------------------------------------");
                    System.out.print("¿Que tipo de vehiculo va a ingresar? (auto, moto, camion) : ");
                    lectura.nextLine();
                    String tipoVehiculo = lectura.nextLine();



                    LocalDateTime entrada = LocalDateTime.now(); // Obtener la hora de entrada

                    // verificacion del tipo de vehiculo a registar
                    switch (tipoVehiculo.toLowerCase()) {
                        

                        case "auto":
                            System.out.println("-------------- REGISTRO DE AUTOMOVIL --------------");
                            System.out.print("Ingrese placa: ");
                            String pla1 = lectura.nextLine();
                            System.out.print("Ingrese marca: ");
                            String mar1 = lectura.nextLine();
                            System.out.print("Ingrese modelo: ");
                            String mod1 = lectura.nextLine();

                            System.out.print("Ingrese tipo de combustible: ");
                            String comb = lectura.nextLine();

                            Automovil auto1 = new Automovil (pla1, mar1, mod1, entrada, comb);
                            parqueadero1.registrarEntrada(auto1);
                            System.out.println("¡Registro de auto exitoso!");
                            break;

                        case "moto":
                            System.out.println("-------------- REGISTRO DE MOTOCICLETA --------------");
                            System.out.print("Ingrese placa: ");
                            String plac1 = lectura.nextLine();
                            System.out.print("Ingrese marca: ");
                            String marc1 = lectura.nextLine();
                            System.out.print("Ingrese modelo: ");
                            String mode1 = lectura.nextLine();
                            System.out.print("Ingrese cilindraje: ");
                            int cin = lectura.nextInt();

                            Motocicleta moto1 = new Motocicleta (plac1, marc1, mode1, entrada, cin);
                            parqueadero1.registrarEntrada(moto1);
                            System.out.println("¡Registro de moto exitoso!");
                            break;

                        case "camion":
                            System.out.println("-------------- REGISTRO DE CAMION --------------");
                            System.out.print("Ingrese placa: ");
                            String placa1 = lectura.nextLine();
                            System.out.print("Ingrese marca: ");
                            String marca1 = lectura.nextLine();
                            System.out.print("Ingrese modelo: ");
                            String model1 = lectura.nextLine();
                            System.out.print("Ingrese cpacidad de carga (en toneladas): ");
                            double car = lectura.nextDouble();

                            Camion cam1 = new Camion (placa1, marca1, model1, entrada, car);
                            parqueadero1.registrarEntrada(cam1);
                            System.out.println("¡Registro de camion exitoso!");
                            break;

                         default:
                            System.out.println("------------ Tipo de vehiculo no valido --------------");
                            break;
                        }
                    break;

                case 2: //Registro de salida de vehiculo
                    System.out.println("-------------- REGISTRO DE SALIDA --------------");
                    System.out.print("Placa del vehiculo que va a salir: ");
                    lectura.nextLine();
                    String salidaPlaca = lectura.nextLine();

                    Vehiculo vehiculoEncontrado = parqueadero1.buscarVehiculoPorPlaca(salidaPlaca);

                    if (vehiculoEncontrado != null) {
                        long costoFinal = parqueadero1.calculoCosto(vehiculoEncontrado);
                        parqueadero1.eliminarRegistro(vehiculoEncontrado);
                        System.out.println("¡Resgistro de salida existoso!");
                        System.out.println();
                        System.out.println("pago total: $" + costoFinal);
                    } else {
                        System.out.println("Vehiculo no encontrado");
                    }
                    break;

                case 3: // consulta del estado del parqueadero
                    System.out.println("-------------- ESTADO DEL PARQUEADERO --------------");
                    parqueadero1.consultarEstado();
                    break;

                case 4:
                    salir = true;
                    break;

                default:
                    System.out.println("Opción invalida.");

            if (!salir) {
                System.out.print("¿Desea regresar al menu? (S/N): ");
                String respuesta = lectura.nextLine().toUpperCase();
                if (!respuesta.equals("S")) {
                    salir = true;
                }
            }    
        }

    }
}
}
