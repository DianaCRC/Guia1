package com.mycompany.proyectoparqueader;

import java.time.*;
import java.util.*;

public class Camion extends Vehiculo {
    // ATRIBUTOS
    // placa
    // marca
    // modelo
    // horaEntrada
    private double capacidadCarga;

    // contructor con parametros
    public Camion (String placa, String marca, String modelo, LocalDateTime horaEntrada, double capacidadCarga) {
        super(placa, marca, modelo, horaEntrada); // super llama al constructor de la clase Vehiculo
        this.capacidadCarga = capacidadCarga;
    }

    // GETTERS Y SETTERS
    // capacidad de carga
    public double getCapacidadCarga() {
        return capacidadCarga;
    }

    public void setCapacidadCarga(double capacidadCarga) {
        this.capacidadCarga = capacidadCarga;
    }
}